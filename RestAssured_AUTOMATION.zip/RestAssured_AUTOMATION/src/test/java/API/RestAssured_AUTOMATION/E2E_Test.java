package API.RestAssured_AUTOMATION;

import io.restassured.response.Response;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.lessThan;

import org.junit.Test;

public class E2E_Test {
	
	@Test
	public void authAndTest() {
		
		String endpointUrl = "/posts";
		
		RequestPOJO requestPOJO = new RequestPOJO();
		requestPOJO.setTitle("Test Post");
		requestPOJO.setBody("This is a test post created using Postman.");
		requestPOJO.setUserId(1);
		
		ResponsePOJO response = given(SpecBuilder.getRequestSpec())
				.body(requestPOJO)
                .when().post(endpointUrl)
                .then().assertThat().statusCode(201)
                .time(lessThan(5000L))
               .extract().response().as(ResponsePOJO.class);
		System.out.println("response----" + response.getTitle());
    }    
		
	}


