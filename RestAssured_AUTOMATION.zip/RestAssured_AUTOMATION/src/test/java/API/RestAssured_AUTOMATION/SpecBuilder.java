package API.RestAssured_AUTOMATION;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class SpecBuilder {
	
	//static String token="";
	public static RequestSpecification getRequestSpec(){
		Headers myheader = new Headers();
	return new RequestSpecBuilder().setBaseUri("http://jsonplaceholder.typicode.com")
					  //.setBasePath("/posts")
					  .addHeaders(myheader.getHeaders())
					  //.setBody(requestPOJO)
					  .setContentType(ContentType.JSON).log(LogDetail.ALL).build();
	
	
	
			
	}
	

}
