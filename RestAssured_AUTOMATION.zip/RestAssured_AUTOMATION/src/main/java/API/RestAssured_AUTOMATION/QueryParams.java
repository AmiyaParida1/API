package API.RestAssured_AUTOMATION;

import java.util.HashMap;

public class QueryParams{

	public static HashMap<String, String> getQueryParams(){
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put(null, null);
		
		
		return queryParams;
		
		
	}

}
