package API.RestAssured_AUTOMATION;

import java.util.HashMap;

public class Headers{

	public static HashMap<String, String> getHeaders(){
		HashMap<String, String> heasders = new HashMap<>();
		heasders.put("Content-Type", "application/json");
	
		return heasders;
		
		
	}

}
