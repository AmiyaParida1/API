package API.RestAssured_AUTOMATION;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DBConnection {
	
	public List<String> fetchData(String GFQA) throws SQLException{
		
		List<String> data = new ArrayList<String>();
		
		String Host = "localhost";
		String port = "3306";
		
		Connection con = DriverManager.getConnection("jdbc:mysql://"+Host+":"+port+"/automation","root","MySQLABC");
		PreparedStatement  preparedStatement = con.prepareStatement("select * from Automation_Data where GFQA = ? ");
		preparedStatement.setString(1, GFQA);
		ResultSet resultSet = preparedStatement.executeQuery();
				
			 
		
			while (resultSet.next()) {
				data.add(resultSet.getString("name"));
				data.add(resultSet.getString("password"));
			} 
		
		return data;
		
		
	}
}





//public class DBConnection {
//
//    public String fetchData(String GFQA) throws SQLException {
//
//        String data = ""; // Change the data type to String
//
//        String Host = "localhost";
//        String port = "3306";
//
//        try (Connection con = DriverManager.getConnection("jdbc:mysql://" + Host + ":" + port + "/automation", "root",
//                "MySQLABC")) {
//            try (PreparedStatement preparedStatement = con
//                    .prepareStatement("select * from Automation_Data where GFQA = ? ")) {
//                preparedStatement.setString(1, GFQA);
//                try (ResultSet resultSet = preparedStatement.executeQuery()) {
//
//                    while (resultSet.next()) {
//                        // Concatenate the values into a single String
//                        data += resultSet.getString("name") + " " + resultSet.getString("password") + " ";
//                    }
//                }
//            }
//        }
//
//        return data.trim(); // Remove trailing whitespace
//    }
//}


//public class DBConnection {
//	
//	public String  fetchData(String GFQA) throws SQLException{
//		
//		String title = null;
//		
//		String Host = "localhost";
//		String port = "3306";
//		
//		Connection con = DriverManager.getConnection("jdbc:mysql://"+Host+":"+port+"/automation","root","MySQLABC");
//		java.sql.Statement s = con.createStatement();
//		ResultSet resultSet = s.executeQuery("select * from Automation_Data where TC_ID ="+GFQA);
//				
//			 
//			while (resultSet.next()) {
//				String name = resultSet.getString("name");
//				String password = resultSet.getString("password");
//			}
//			
//			return title; 
//			
//	
//	}
//}
